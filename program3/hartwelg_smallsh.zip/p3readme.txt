Compile smallsh.c with:
gcc -o smallsh smallsh.c
